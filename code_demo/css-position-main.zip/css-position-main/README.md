<h1>CSS: Positioning 5-Ways</h1>
<p>This project is showing 5 ways to position elements with CSS</p>

Check it out at: https://lange-lange.github.io/css-position/
